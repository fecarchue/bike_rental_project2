#include "main.h"

int main() {
    doTask();
    return 0;
}